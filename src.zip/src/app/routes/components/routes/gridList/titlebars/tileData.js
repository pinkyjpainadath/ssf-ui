const tileData = [
  {
    img: "https://via.placeholder.com/500x330",
    title: 'Breakfast',
    author: 'jill111',
  },
  {
    img: "https://via.placeholder.com/500x330",
    title: 'Tasty burger',
    author: 'director90',
  },
  {
    img: "https://via.placeholder.com/500x330",
    title: 'Mushroom',
    author: 'Danson67',
  },
  {
    img: "https://via.placeholder.com/500x330",
    title: 'Morning',
    author: 'fancycrave1',
  },
  {
    img: "https://via.placeholder.com/500x330",
    title: 'Hats',
    author: 'Hans',
  },
  {
    img: "https://via.placeholder.com/500x330",
    title: 'Honey',
    author: 'fancycravel',
  },
  {
    img: "https://via.placeholder.com/500x330",
    title: 'Vegetables',
    author: 'jill111',
  },
  {
    img: "https://via.placeholder.com/500x330",
    title: 'Water plant',
    author: 'BkrmadtyaKarki',
  },
  {
    img:"https://via.placeholder.com/500x330",
    title: 'Mushrooms',
    author: 'PublicDomainPictures',
  },
  {
    img: "https://via.placeholder.com/500x330",
    title: 'Olive oil',
    author: 'congerdesign',
  },
  {
    img: "https://via.placeholder.com/500x330",
    title: 'Sea star',
    author: '821292',
  },
  {
    img: "https://via.placeholder.com/500x330",
    title: 'Bike',
    author: 'danfador',
  },
];

export default tileData;
